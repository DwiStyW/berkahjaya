@extends('layout.master')
@section('title')
    Pembelian
@endsection
@section('css')
    <!-- DataTables -->
    <link href="{{ URL::asset('/assets/libs/datatables/datatables.min.css') }}" rel="stylesheet" type="text/css" />
    <style>
        table.dataTable.cell-border thead th {
            border: 1px solid rgba(0, 0, 0, 0.25);
            text-align: center;
        }

        table.dataTable.cell-border tbody th,
        table.dataTable.cell-border tbody td {
            border-top: 1px solid rgba(0, 0, 0, 0.15);
            border-right: 1px solid rgba(0, 0, 0, 0.15);
            border-bottom: 1px solid rgba(0, 0, 0, 0.15);
            padding: 5px 10px 5px 10px;
        }

        table.dataTable.cell-border thead tr th {
            padding: 5px 10px 5px 10px;
        }

        table.dataTable.cell-border tbody tr th:first-child,
        table.dataTable.cell-border tbody tr td:first-child {
            border-left: 1px solid rgba(0, 0, 0, 0.15);
        }

        /* table.dataTable.cell-border tbody tr:first-child th,
                table.dataTable.cell-border tbody tr:first-child td {
                    border-top: none;
                } */
    </style>
@endsection
@section('content')
    @component('common-components.breadcrumb')
        @slot('pagetitle')
            Berkah Jaya
        @endslot
        @slot('title')
            Pembelian
        @endslot
    @endcomponent

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    @php
                        $total_jumlah = [];
                        $total_volume = [];
                        $total_harga = [];
                    @endphp
                    @foreach ($detail_pembelian as $dp)
                    @endforeach
                    @if (count($detail_pembelian) != 0)
                        <h6 class="text-secondary mb-1">{{ $dp->tanggal }} <b>{{ $dp->supplier }}</b></h6>
                        <h6 class="float-end">{{ $dp->kode_pembelian }}</h6>
                    @endif

                    @foreach ($detail_pembelian_group as $i)
                        <h6 class="text-secondary">{{ $i->jenis_muatan }}</h6>
                        <div class="mb-3">
                            <table id="datatable{{ $i->id_master_mentah }}"
                                class="dataTable cell-border dt-responsive nowrap "
                                style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                <thead class="bg-secondary text-white">
                                    <tr>
                                        <th colspan="2">Model</th>
                                        <th>Pakem</th>
                                        <th>Jumlah</th>
                                        <th>Volume</th>
                                        <th>Harga</th>
                                        <th>Total</th>
                                        {{-- <th>Aksi</th> --}}
                                    </tr>

                                </thead>

                                <tbody>
                                    @php
                                        $jumlah = [];
                                        $vol = [];
                                        $total = [];
                                    @endphp
                                    @foreach ($detail_pembelian as $item)
                                        @if ($i->id_master_mentah == $item->id_master_mentah)
                                            @php
                                                array_push($jumlah, $item->jumlah);
                                                array_push($vol, $item->vol);
                                                array_push($total, $item->total_harga);
                                            @endphp
                                            <tr>

                                                <td>{{ $item->kelas_model }}</td>
                                                <td>{{ $item->model }}</td>
                                                <td>{{ $item->pakem_pembulatan }}</td>
                                                <td>{{ $item->jumlah }}</td>
                                                <td>{{ $item->vol }}</td>
                                                <td>{{ $item->harga_model }}</td>
                                                <td>{{ $item->total_harga }}</td>
                                                {{-- <td>
                                                    <ul class="list-inline mb-0">
                                                        <li class="list-inline-item">
                                                            <a onclick="hapus('{{ Crypt::encrypt($item->id) }}')"
                                                                data-bs-toggle="modal" data-bs-target="#hapusmodal"
                                                                class="px-2 text-danger">
                                                                <i class="uil uil-trash-alt font-size-18"></i>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </td> --}}
                                            </tr>
                                        @endif
                                    @endforeach
                                </tbody>
                                <tbody>
                                    <tr>
                                        <th colspan="3">Total</th>
                                        <th>{{ array_sum($jumlah) }}</th>
                                        <th>{{ array_sum($vol) }}</th>
                                        <th></th>
                                        <th>{{ 'Rp ' . number_format(array_sum($total), 0, ',', '.') }}</th>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        @php
                            array_push($total_jumlah, array_sum($jumlah));
                            array_push($total_volume, array_sum($vol));
                            array_push($total_harga, array_sum($total));
                        @endphp
                    @endforeach
                    {{-- <div class="float-end">
                        <a href="/pembelian-store" onclick="resetVal()" id="simpan_produksi"
                            class="btn btn-md btn-primary">Simpan</a>
                    </div> --}}
                    <div class="mt-3">
                        <table class="w-50 dataTable cell-border" style="border-collapse: collapse; border-spacing: 0;">
                            <tbody>
                                <tr>
                                    <th>Total Volume</th>
                                    <td>{{ array_sum($total_volume) }}</td>
                                </tr>
                                <tr>
                                    <th>Total Harga</th>
                                    <td>{{ 'Rp ' . number_format(array_sum($total_harga), 0, ',', '.') }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            {{-- </div> <!-- end col --> --}}
        </div> <!-- end col -->
    </div> <!-- end row -->
    @include('pembelian.delete-pembelian')
@endsection
@section('script')
    <script src="{{ URL::asset('/assets/libs/datatables/datatables.min.js') }}"></script>
    <script src="{{ URL::asset('/assets/libs/jszip/jszip.min.js') }}"></script>
    <script src="{{ URL::asset('/assets/libs/pdfmake/pdfmake.min.js') }}"></script>
    {{-- <script src="{{ URL::asset('/assets/js/pages/datatables.init.js') }}"></script> --}}
    <script src="//cdn.rawgit.com/ashl1/datatables-rowsgroup/v2.0.0/dataTables.rowsGroup.js"></script>
    <script>
        $(document).ready(function() {
            $('#datatable1').DataTable({
                dom: '<"table-responsive w-100"<t>>',
                rowsGroup: [0],
                columnDefs: [{
                    render: $.fn.dataTable.render.number('.', ',', 0, 'Rp '),
                    targets: [5, 6]
                }]
            });
        });
        $(document).ready(function() {
            $('#datatable2').DataTable({
                dom: '<"table-responsive w-100"<t>>',

                columnDefs: [{
                    render: $.fn.dataTable.render.number('.', ',', 0, 'Rp '),
                    targets: [5, 6]
                }]
            });
        });
        $(document).ready(function() {
            $('#datatable3').DataTable({
                dom: '<"table-responsive w-100"<t>>',

                columnDefs: [{
                    render: $.fn.dataTable.render.number('.', ',', 0, 'Rp '),
                    targets: [5, 6]
                }]
            });
        });
        $(document).ready(function() {
            $('#datatable4').DataTable({
                dom: '<"table-responsive w-100"<t>>',

                columnDefs: [{
                    render: $.fn.dataTable.render.number('.', ',', 0, 'Rp '),
                    targets: [5, 6]
                }]
            });
        });
        $(document).ready(function() {
            $('#datatable5').DataTable({
                dom: '<"table-responsive w-100"<t>>',

                columnDefs: [{
                    render: $.fn.dataTable.render.number('.', ',', 0, 'Rp '),
                    targets: [5, 6]
                }]
            });
        });
        $(document).ready(function() {
            $('#datatable6').DataTable({
                dom: '<"table-responsive w-100"<t>>',

                columnDefs: [{
                    render: $.fn.dataTable.render.number('.', ',', 0, 'Rp '),
                    targets: [5, 6]
                }]
            });
        });
    </script>
@endsection
